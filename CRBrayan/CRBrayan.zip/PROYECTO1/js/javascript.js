//var Name=const MiBoton = () =>{
  //    let inputValue = document.getElementById("username").value; 




function MiBoton(){
    
    var Name=document.getElementById("username").value;
    var password=document.getElementById("password").value;
    
    if(Name=="Brianfury" && password=="12345"){
   alert("Es correcto");
        
   }
    
else{
    alert("Los datos son incorrectos");
}

}

